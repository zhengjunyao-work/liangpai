
#include <algorithm>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;


struct Row{
    int timestamp;
    string symbol;
    int quantity;
    int price;
};

// mtg: maximum time gap
// vol: total volume
// wap: weighted average price
// mtp: maximum trade price
// lt: timestamp for last trade 

// any additional variables can be added in this struct 
struct output{
    string symbol;
    int mtg ;
    int vol ;
    double wap ;
    int mtp ;
    int lt ;

};

int getIndex(vector<string> v, string K)
{
    auto it = find(v.begin(), v.end(), K);
    int index;
    // If element was found
    if (it != v.end())
    {
     
        // calculating the index
        // of K
        index = it - v.begin();
       
    }
    else {
        // If the element is not
        // present in the vector
        cout << "-1" << endl;
    }
    return index;
}
int main(int argc, char* argv[]) {
    string input_file, output_file;

    //read in file names 
    if(argc >2){
        input_file = argv[1];
        output_file = argv[2];
    }


    // open input file
    ifstream infile(input_file);
    string line;
    std::vector<Row> table;
   
   //store input data in struct
    while(getline(infile,line)){
        Row data;
        istringstream ss(line);
        string token;
        ss >> data.timestamp >> data.symbol 
    >>data.quantity >> data.price;
        table.push_back(data);
        
    }

    //display table of trading information
    for (int i=0;i< table.size();i++) {
    cout << table[i].timestamp<<"  ";
    cout << table[i].symbol<<" ";
    cout << table[i].quantity<<"  ";
    cout << table[i].price << "   "<<endl;
    }   
  

    std::vector<output> table2;
    std::vector<string> symbols;

    //find all traded symbol on the day
    for(int i = 1 ;i<table.size();++i){
        if (find(symbols.begin(), symbols.end(), table[i].symbol) == symbols.end()) {
            symbols.push_back(table[i].symbol);
        
        }

    }
    sort(symbols.begin(),symbols.end());

    //initialize output table
    for(int i = 0;i<symbols.size();++i){
        output temp;
        temp.symbol=symbols[i];
        temp.mtg=0;
        temp.wap=0;
        temp.mtp=0;
        temp.vol=0;
        temp.lt=0;
        table2.push_back(temp);

    }
    string temp;

    //Calculation for different variables
    for(int i =1;i<table.size();++i){
        int index = getIndex(symbols,table[i].symbol);
        
        if(table2[index].lt != 0){
            if(table[i].timestamp-table2[index].lt > table2[index].mtg){
                table2[index].mtg = table[i].timestamp-table2[index].lt;
            }
        }

        table2[index].lt = table[i].timestamp;

        //total volume
        table2[index].vol+=table[i].quantity;

        //total money traded
        table2[index].wap+= table[i].quantity * table[i].price;

        //maximum trade price
        if(table2[index].mtp < table[i].price){
            table2[index].mtp  = table[i].price;
        }

    }

    //weighted average price  --- total price / total volume
    for(int i =0;i<table2.size();++i){
        table2[i].wap = table2[i].wap/table2[i].vol;

    }



    //any additional variables can be computed here and add it to the struct


    //display output table
    for (int i=0;i< table2.size();i++) {
        cout << table2[i].symbol<<"  ";
        cout << table2[i].mtg<<" ";
        cout << table2[i].wap<<"  ";
        cout << table2[i].mtp << "   "<<endl;
        }   
  


    //store output table in a csv file
    std::ofstream opfile;
    opfile.open(output_file);

    //any additional variables can be added to the output file by 
    //modifying this piece of code. 

    opfile << "Symbol,MaxTimeGap,Volume,WeightedAveragePrice,MaxPrice\n";
    for(int i =0;i<table2.size();++i){
        opfile <<table2[i].symbol<<','<<table2[i].mtg<<','<<table2[i].vol<<
        ','<<table2[i].wap<<','<<table2[i].mtp<<'\n';

    }


    return 0;



    
}
